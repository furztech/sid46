var app=angular.module('StudentData',[]);

(function(){


app.controller('DataController',function(){
this.Student=StudentData;
});


var StudentData=[
{
"name":"a",
"Rollno":1,
"marks":90,
"class":"12",
"school":"kg public school",

},
{
"name":"b",
"Rollno":2,
"marks":80,
"class":"12",
"school":"kg public school",

},
{
"name":"c",
"Rollno":3,
"marks":95,
"class":"12",
"school":"kg public school",

},
{
"name":"d",
"Rollno":4,
"marks":85,
"class":"12",
"school":"kg public school",

},
{
"name":"e",
"Rollno":5,
"marks":97,
"class":"12",
"school":"kg public school",

},
{
"name":"f",
"Rollno":6,
"marks":90,
"class":"12",
"school":"kg public school",

},
{
"name":"g",
"Rollno":7,
"marks":80,
"class":"12",
"school":"kg public school",

},
{
"name":"h",
"Rollno":8,
"marks":99,
"class":"12",
"school":"kg public school",

},
{
"name":"i",
"Rollno":9,
"marks":70,
"class":"12",
"school":"kg public school",

},
{
"name":"j",
"Rollno":10,
"marks":98,
"class":"12",
"school":"kg public school",

},
{
"name":"k",
"Rollno":11,
"marks":82,
"class":"12",
"school":"kg public school",

},
{
"name":"l",
"Rollno":12,
"marks":92,
"class":"12",
"school":"kg public school",

},
{
"name":"m",
"Rollno":13,
"marks":92,
"class":"12",
"school":"kg public school",

},
{
"name":"n",
"Rollno":14,
"marks":93,
"class":"12",
"school":"kg public school",

},
{
"name":"o",
"Rollno":15,
"marks":83,
"class":"12",
"school":"kg public school",

},
{
"name":"p",
"Rollno":16,
"marks":93,
"class":"12",
"school":"kg public school",

},
{
"name":"q",
"Rollno":17,
"marks":82,
"class":"12",
"school":"kg public school",

},
{
"name":"r",
"Rollno":18,
"marks":86,
"class":"12",
"school":"kg public school",

},
{
"name":"s",
"Rollno":19,
"marks":92,
"class":"12",
"school":"kg public school",

},
{
"name":"t",
"Rollno":20,
"marks":97,
"class":"12",
"school":"kg public school",

}
];


})();
