(function(){
  var app=angular.module('Lifeline',['ngRoute']);

app.controller('LifelineController',function()
{
  this.organisation=hospital;
  console.log('hello');
});


var hospital=[
{
  name:'kg hospital',
  place: 'near race course',
  registration: '100',
  image:'Lifeline.jpg',
},
{
  name:'ganga hospital',
  place: 'saibaba colony',
  registration: '200',
  image:'Lifeline.jpg',
},
{
  name:'abirami hosptal',
  place: 'sundharapuram',
  registration: '300',
  image:'Lifeline.jpg',
}
];
})();
